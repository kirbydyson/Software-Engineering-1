package test;

import dbAssignment.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.sql.*;
import java.util.*;

import static org.junit.Assert.*;

public class EmployeeDTOTest {
    private EmployeeDTO employeeDTO;

    @Before
    public void setUp() throws SQLException {
        employeeDTO = new EmployeeDTO();
    }

    @After
    public void tearDown() throws SQLException {
        List<Employee> employees = employeeDTO.findAll();
        for (Employee emp : employees) {
            employeeDTO.delete(emp.getId());
        }
    }

    private Employee createAndSaveEmployee(String name) throws SQLException {
        Employee employee = new Employee(null, name, "kirby_dyson1@baylor.edu", 20, "Female", 10000000);
        employeeDTO.save(employee);
        return employeeDTO.findById(employee.getId());
    }

    @Test
    public void testSave() throws SQLException {
        Employee employee = createAndSaveEmployee("Kirby Dyson");
        assertNotNull(employee);
        assertEquals("Kirby Dyson", employee.getName());
        assertEquals("kirby_dyson1@baylor.edu", employee.getEmail());
        assertEquals("Female", employee.getGender());
    }

    @Test
    public void testUpdate() throws SQLException {
        Employee employee = createAndSaveEmployee("Kirby Dyson");
        employee.setName("John Doe");
        employeeDTO.save(employee);

        Employee updatedEmployee = employeeDTO.findById(employee.getId());
        assertNotNull(updatedEmployee);
        assertEquals("John Doe", updatedEmployee.getName());
    }

    @Test
    public void testFindById() throws SQLException {
        Employee employee = createAndSaveEmployee("Kirby Dyson");
        Employee foundEmployee = employeeDTO.findById(employee.getId());
        assertNotNull(foundEmployee);
        assertEquals("Kirby Dyson", foundEmployee.getName());
    }

    @Test
    public void testDelete() throws SQLException {
        Employee employee = createAndSaveEmployee("Kirby Dyson");
        employeeDTO.delete(employee.getId());
        Employee deletedEmployee = employeeDTO.findById(employee.getId());
        assertNull(deletedEmployee);
    }

    @Test
    public void testFindAll() throws SQLException {
        createAndSaveEmployee("Kirby Dyson");
        List<Employee> employees = employeeDTO.findAll();
        assertNotNull(employees);
        assertTrue(employees.size() >= 1);
    }

    @Test
    public void testCount() throws SQLException {
        createAndSaveEmployee("Kirby Dyson");
        long count = employeeDTO.count();
        assertTrue(count >= 1);
    }

    @Test
    public void testFind() throws SQLException {
        createAndSaveEmployee("Kirby Dyson");
        Set<Employee> employees = employeeDTO.find("age < 25 AND gender = 'Female'");
        assertTrue(employees.size() >= 1);
    }
}
