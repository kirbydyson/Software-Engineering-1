package dbAssignment;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class EmployeeDTO {
    private static final String DB_CONNECTION = "jdbc:derby:EmployeeDB;create=true";

    public EmployeeDTO() throws SQLException {
        createDbUserTable();
    }

    private static Connection getDBConnection() throws SQLException {
        return DriverManager.getConnection(DB_CONNECTION);
    }

    private static void createDbUserTable() throws SQLException {
        try (Connection dbConnection = getDBConnection();
             Statement statement = dbConnection.createStatement()) {

            DatabaseMetaData dbm = dbConnection.getMetaData();
            ResultSet tables = dbm.getTables(null, null, "Employee", null);

            if (!tables.next()) {
                String createTableSQL = "CREATE TABLE Employee (" +
                        "id INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1)," +
                        "name VARCHAR(255) NOT NULL," +
                        "email VARCHAR(255) NOT NULL," +
                        "age INTEGER NOT NULL," +
                        "gender VARCHAR(10) NOT NULL," +
                        "salary DOUBLE NOT NULL," +
                        "PRIMARY KEY (id))";
                statement.execute(createTableSQL);
            }
        }
    }

    public void save(Employee employee) throws SQLException {
        String query = (employee.getId() == null) ?
                "INSERT INTO Employee (name, email, age, gender, salary) VALUES (?, ?, ?, ?, ?)" :
                "UPDATE Employee SET name=?, email=?, age=?, gender=?, salary=? WHERE id=?";

        try (Connection connection = getDBConnection();
             PreparedStatement ps = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, employee.getName());
            ps.setString(2, employee.getEmail());
            ps.setInt(3, employee.getAge());
            ps.setString(4, employee.getGender());
            ps.setDouble(5, employee.getSalary());

            if (employee.getId() != null) {
                ps.setInt(6, employee.getId());
            }

            ps.executeUpdate();

            if (employee.getId() == null) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        employee.setId(rs.getInt(1));
                    }
                }
            }
        }
    }

    public Employee findById(int id) throws SQLException {
        String query = "SELECT * FROM Employee WHERE id = ?";
        try (Connection connection = getDBConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Employee(rs.getInt("id"), rs.getString("name"), rs.getString("email"),
                            rs.getInt("age"), rs.getString("gender"), rs.getDouble("salary"));
                }
            }
        }
        return null;
    }

    public List<Employee> findAll() throws SQLException {
        List<Employee> employees = new ArrayList<>();
        String query = "SELECT * FROM Employee";
        try (Connection connection = getDBConnection();
             Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery(query)) {

            while (rs.next()) {
                employees.add(new Employee(rs.getInt("id"), rs.getString("name"), rs.getString("email"),
                        rs.getInt("age"), rs.getString("gender"), rs.getDouble("salary")));
            }
        }
        return employees;
    }

    public void delete(int id) throws SQLException {
        String query = "DELETE FROM Employee WHERE id = ?";
        try (Connection connection = getDBConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public long count() throws SQLException {
        String query = "SELECT COUNT(*) AS total FROM Employee";
        try (Connection connection = getDBConnection();
             Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery(query)) {

            return rs.next() ? rs.getLong("total") : 0;
        }
    }

    public Set<Employee> find(String condition) throws SQLException {
        Set<Employee> employees = new HashSet<>();
        String query = "SELECT * FROM Employee WHERE " + condition;
        try (Connection connection = getDBConnection();
             Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery(query)) {

            while (rs.next()) {
                employees.add(new Employee(rs.getInt("id"), rs.getString("name"), rs.getString("email"),
                        rs.getInt("age"), rs.getString("gender"), rs.getDouble("salary")));
            }
        }
        return employees;
    }
}
