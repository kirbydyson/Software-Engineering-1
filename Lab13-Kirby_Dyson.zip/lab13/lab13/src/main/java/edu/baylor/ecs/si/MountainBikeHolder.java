package edu.baylor.ecs.si;

public class MountainBikeHolder extends BicycleHolder {
    public MountainBikeHolder(MountainBike bike) {
        super(bike);
    }
}
