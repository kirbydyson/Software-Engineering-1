package edu.baylor.ecs.si;

public class BicycleHolder {
    private Bicycle bike;

    public BicycleHolder(Bicycle bike) {
        this.bike = bike;
    }

    public Bicycle getBicycle() {
        return bike;
    }
}
