package edu.baylor.ecs.si;

public class BasicService {
    public void accept(Bicycle bike) {
        System.out.println("fixing Bicycle");
    }
}
