package edu.baylor.ecs.si;

public class RoadBikeHolder extends BicycleHolder {
    public RoadBikeHolder(RoadBike bike) {
        super(bike);
    }
}
