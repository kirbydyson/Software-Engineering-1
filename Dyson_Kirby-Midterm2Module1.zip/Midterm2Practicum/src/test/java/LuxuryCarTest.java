import org.example.module1.*;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;


class LuxuryCarTest {
    private LuxuryCar car1;
    private LuxuryCar car2;
    private LuxuryCar car3;

    @BeforeEach
    void setUp() throws Exception {
        car1 = new LuxuryCar("Ferrari", "296GTS", "2023", "v4.0", new LuxuryCarEngine(40, "v5.0"));
        car2 = new LuxuryCar("Mercedes-Benz", "Maybach S 580", "2015", "v4.0", new LuxuryCarEngine(40, "v5.0"));
        car3 = new LuxuryCar("BMW", "Super Nice", "2024", "v3.0", new LuxuryCarEngine(50, "v5.0"));
    }

    @AfterEach
    void tearDown() {
        car1 = null;
        car2 = null;
        car3 = null;
    }

    @Test
    void moveTest() {
        car1.move();
        assertEquals("Power: 40 , Engine Type: Luxury Car Engine", car1.getEngine().power());
        car2.move();
        assertEquals("Power: 40 , Engine Type: Luxury Car Engine", car2.getEngine().power());
        car3.move();
        assertEquals("Power: 50 , Engine Type: Luxury Car Engine", car3.getEngine().power());
    }

    @Test
    void wongEngineTypeTest() {
        assertThrows(Car.WrongEngineType.class, () -> {
            new LuxuryCar("Ferrari", "296GTS", "2023", "v4.0", new RegularCarEngine(40, "v5.0"));
        });
    }

    @Test
    void rightEngineTest(){
        if(car1.getEngine() instanceof LuxuryCarEngine) {
            System.out.println("Pass: Luxury Car Engine");
        }
    }

    @Test
    void wrongVersionTest() {
        assertThrows(Car.WrongVersionException.class, () -> {
            new LuxuryCar("Ferrari", "296GTS", "2023", "v4.0", new LuxuryCarEngine(40, "v2.0"));
        });
    }

    @Test
    void takeEngineTest() throws Exception {
        car2.takeEngine(car3);
        assertEquals("v5.0", car2.getEngine().getVersion());
    }
}
