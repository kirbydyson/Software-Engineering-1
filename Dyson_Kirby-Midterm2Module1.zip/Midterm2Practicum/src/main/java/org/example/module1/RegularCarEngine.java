package org.example.module1;

public class RegularCarEngine extends Engine {
    public RegularCarEngine(int power, String version) {
        super(power, version);
    }

    @Override
    public String power() {
        String output = "Power: " + getPower() + " , Engine Type: Regular Car Engine";
        System.out.println(output);
        return output;
    }
}
