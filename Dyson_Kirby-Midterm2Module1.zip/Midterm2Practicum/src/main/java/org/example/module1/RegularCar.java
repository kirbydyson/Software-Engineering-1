package org.example.module1;

public class RegularCar extends Car {
    public RegularCar(String make, String model, String year, String minimumVersion, Engine engine) throws WrongVersionException, WrongEngineType {
        super(make, model, year, minimumVersion, engine);
        if (!(engine instanceof RegularCarEngine)) {
            throw new WrongEngineType("Wrong Engine Type: Should be regular engine.");
        }
    }
}
