package org.example.module1;

public class LuxuryCarEngine extends Engine {
    public LuxuryCarEngine(int power, String version) {
        super(power, version);
    }

    @Override
    public String power() {
        String output = "Power: " + getPower() + " , Engine Type: Luxury Car Engine";
        System.out.println(output);
        return output;
    }
}