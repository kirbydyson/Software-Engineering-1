package org.example.module1;

public abstract class Engine {
    public int power;
    public String version;

    public Engine(int power, String version) {
        if (power < 10 || power > 50) {
            throw new IllegalArgumentException("ERROR: Power ranges between 10 and 50");
        }
        this.power = power;
        this.version = version;
    }

    public int getPower() {
        return power;
    }

    public String getVersion() {
        return version;
    }

    public abstract String power();
}
