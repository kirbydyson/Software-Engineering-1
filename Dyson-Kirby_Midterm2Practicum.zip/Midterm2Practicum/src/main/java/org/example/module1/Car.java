package org.example.module1;

public abstract class Car {
    public String make;
    public String model;
    public String year;
    public String minimumVersion;
    protected Engine engine;

    public Car(String make, String model, String year, String minimumVersion, Engine engine) throws WrongVersionException {
        this.make = make;
        this.model = model;
        this.year = year;
        this.minimumVersion = minimumVersion;

        if (engine.getVersion().compareTo(minimumVersion) < 0) {
            throw new WrongVersionException("ERROR: Engine version is too low.");
        }
        else{
            this.engine = engine;
        }
    }

    public void setMake(String make) {
        this.make = make;
    }
    public String getMake() {
        return make;
    }
    public void setModel(String model) {
        this.model = model;
    }
    public String getModel() {
        return model;
    }
    public void setYear(String year) {
        this.year = year;
    }
    public String getYear() {
        return year;
    }
    public void setMinimumVersion(String minimumVersion) {
        this.minimumVersion = minimumVersion;
    }
    public String getMinimumVersion() {
        return minimumVersion;
    }
    public void setEngine(Engine engine) {
        this.engine = engine;
    }
    public Engine getEngine() {
        return engine;
    }
    public void move() {
        engine.power();
    }

    public void takeEngine(Car car) throws WrongEngineType {
        if (this.getClass() == car.getClass() && engine.getVersion().equals(car.engine.getVersion())) {
            this.engine = car.engine;
        }
        else {
            throw new WrongEngineType("ERROR: Incompatible, engine cannot be replaced");
        }
    }

    public static class WrongVersionException extends Exception {
        public WrongVersionException(String mssg) {
            super(mssg);
        }
    }

    public static class WrongEngineType extends Exception {
        public WrongEngineType(String mssg) {
            super(mssg);
        }
    }
}
