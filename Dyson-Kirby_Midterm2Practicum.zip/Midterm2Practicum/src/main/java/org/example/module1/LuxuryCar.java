package org.example.module1;

public class LuxuryCar extends Car {
    public LuxuryCar(String make, String model, String year, String minimumVersion, Engine engine) throws WrongEngineType, WrongVersionException {
        super(make, model, year, minimumVersion, engine);
        if (!(engine instanceof LuxuryCarEngine)) {
            throw new WrongEngineType("Wrong Engine Type: Should be luxury engine.");
        }
    }
}
