package org.example.module2;

import net.coderazzi.filters.gui.AutoChoices;
import net.coderazzi.filters.gui.TableFilterHeader;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Vector;
import java.util.regex.PatternSyntaxException;

public class TableView extends JPanel {
    private boolean DEBUG = false;
    private JTable table;
    private JTextField filterText;
    private JTextField statusText;
    private TableRowSorter<DefaultTableModel> sorter;

    public TableView() {
        super();
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        String[] columnNames = {"Car Type", "Make", "Model", "Year", "Minimum Version", "Engine Type", "Power", "Engine Version"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
            private final Class<?>[] columnClass = new Class[]{
                    String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class
            };

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }

            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return columnClass[columnIndex];
            }
        };

        loadCSVData(model);

        sorter = new TableRowSorter<>(model);
        table = new JTable(model);
        table.setRowSorter(sorter);
        table.setPreferredScrollableViewportSize(new Dimension(500, 70));
        table.setFillsViewportHeight(true);

        TableFilterHeader filterHeader = new TableFilterHeader(table, AutoChoices.ENABLED);
        table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        table.getSelectionModel().addListSelectionListener(event -> {
            int viewRow = table.getSelectedRow();
            if (viewRow < 0) {
                statusText.setText("");
            } else {
                int modelRow = table.convertRowIndexToModel(viewRow);
                statusText.setText(String.format("Selected Row in view: %d. Selected Row in model: %d.", viewRow, modelRow));
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        add(scrollPane);

        JPanel form = new JPanel(new SpringLayout());
        JLabel l1 = new JLabel("Filter Text:", SwingConstants.TRAILING);
        form.add(l1);
        filterText = new JTextField();
        filterText.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) { newFilter(); }
            public void insertUpdate(DocumentEvent e) { newFilter(); }
            public void removeUpdate(DocumentEvent e) { newFilter(); }
        });
        l1.setLabelFor(filterText);
        form.add(filterText);
        JLabel l2 = new JLabel("Status:", SwingConstants.TRAILING);
        form.add(l2);
        statusText = new JTextField();
        l2.setLabelFor(statusText);
        form.add(statusText);
        SpringUtilities.makeCompactGrid(form, 2, 2, 6, 6, 6, 6);
        add(form);

        JButton button = new JButton("Remove");
        button.addActionListener(new RemoveLineActionListener());
        add(button);

        JButton dialogButton = new JButton("Duplicate & Edit");
        dialogButton.addActionListener(e -> {
            int[] selectedRows = table.getSelectedRows();

            if (selectedRows.length == 0) {
                JOptionPane.showMessageDialog(null, "No row selected; provide inputs to all fields and press [Add Row] button.");

                SwingUtilities.invokeLater(() -> {
                    MyDialog dialog = new MyDialog((JFrame) SwingUtilities.getWindowAncestor(this), table, new Vector<>(), false);
                    dialog.setVisible(true);
                });
            } else if (selectedRows.length == 1) {
                JOptionPane.showMessageDialog(null,
                        "You selected this row as initial inputs. Please revise them as needed and press [Add Row] button.");
                int selectedRow = selectedRows[0];
                Vector<Object> rowData = new Vector<>();

                int modelRow = table.convertRowIndexToModel(selectedRow);
                for (int i = 0; i < table.getColumnCount(); i++) {
                    rowData.add(table.getModel().getValueAt(modelRow, i));
                }

                SwingUtilities.invokeLater(() -> {
                    MyDialog dialog = new MyDialog((JFrame) SwingUtilities.getWindowAncestor(this), table, rowData, true);
                    dialog.setVisible(true);
                });
            } else {
                JOptionPane.showMessageDialog(null, "Cannot duplicate multiple rows.");
            }
        });
        add(dialogButton);
    }

    private void loadCSVData(DefaultTableModel model) {
        try (InputStream inputStream = getClass().getResourceAsStream("/cars.csv");
             BufferedReader br = new BufferedReader(new InputStreamReader(inputStream))) {
            if (inputStream == null) {
                throw new FileNotFoundException("Resource 'cars.csv' not found in classpath.");
            }

            String line;
            while ((line = br.readLine()) != null) {
                String[] row = line.split(",");
                Vector<Object> correction = new Vector<>();
                for (int i = 0; i < model.getColumnCount(); i++) {
                    correction.add(row[i]);
                }
                model.addRow(correction);
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Issue with loading file: " + ex.getMessage());
            ex.printStackTrace();
        }
    }


    private class RemoveLineActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int viewRow = table.getSelectedRow();
            if (viewRow < 0) {
                JOptionPane.showMessageDialog(null, "No row selected!");
            } else {
                int modelRow = table.convertRowIndexToModel(viewRow);
                DefaultTableModel model = (DefaultTableModel) table.getModel();
                int answer = JOptionPane.showConfirmDialog(null, "Do you want to remove " + model.getValueAt(modelRow, 0) + " " + model.getValueAt(modelRow, 1) + "?", "Warning", JOptionPane.YES_NO_OPTION);
                if (answer == 0) {
                    model.removeRow(modelRow);
                    updateCSVData(model);
                }
            }
        }
    }

    private void newFilter() {
        try {
            sorter.setRowFilter(RowFilter.regexFilter(filterText.getText(), 0, 1, 2));
        } catch (PatternSyntaxException e) {
            return;
        }
    }

    private void updateCSVData(DefaultTableModel model) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("cars.csv"))) {
            for (int i = 0; i < model.getColumnCount(); i++) {
                writer.write(model.getColumnName(i));
                if (i < model.getColumnCount() - 1) writer.write(",");
            }
            writer.newLine();

            for (int i = 0; i < model.getRowCount(); i++) {
                for (int j = 0; j < model.getColumnCount(); j++) {
                    writer.write(model.getValueAt(i, j).toString());
                    if (j < model.getColumnCount() - 1) writer.write(",");
                }
                writer.newLine();
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Error updating CSV: " + ex.getMessage());
        }
    }

    private static void createAndShowGUI() {
        JFrame frame = new JFrame("Table View");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        TableView newContentPane = new TableView();
        newContentPane.setOpaque(true);
        frame.setContentPane(newContentPane);
        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(TableView::createAndShowGUI);
    }
}
