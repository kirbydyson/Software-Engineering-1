package org.example.module2;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Vector;

public class MyDialog extends JDialog {
    private JComboBox<String> carTypeComboBox;
    private JComboBox<String> engineTypeComboBox;
    private JComboBox<String> minimumVersionComboBox;
    private JComboBox<String> engineVersionComboBox;
    private JTextField makeField;
    private JTextField modelField;
    private JTextField yearField;
    private JTextField powerField;
    private JTable table;

    public MyDialog(JFrame parent, JTable table, Vector<Object> rowData, boolean isEdit) {
        super(parent, isEdit ? "Edit Car" : "Add New Car", true);
        setLayout(new BorderLayout());

        this.table = table;

        carTypeComboBox = new JComboBox<>(new String[]{"RegularCar", "LuxuryCar"});
        engineTypeComboBox = new JComboBox<>(new String[]{"RegularCarEngine", "LuxuryCarEngine"});
        minimumVersionComboBox = new JComboBox<>(new String[]{"0", "v2.0", "v3.0", "v4.0", "v5.0"});
        engineVersionComboBox = new JComboBox<>(new String[]{"0", "v2.0", "v3.0", "v4.0", "v5.0"});

        makeField = new JTextField();
        modelField = new JTextField();
        yearField = new JTextField();
        powerField = new JTextField();

        JPanel formPanel = new JPanel(new GridLayout(8, 2));
        formPanel.add(new JLabel("Car Type:"));
        formPanel.add(carTypeComboBox);
        formPanel.add(new JLabel("Make:"));
        formPanel.add(makeField);
        formPanel.add(new JLabel("Model:"));
        formPanel.add(modelField);
        formPanel.add(new JLabel("Year:"));
        formPanel.add(yearField);
        formPanel.add(new JLabel("Power:"));
        formPanel.add(powerField);
        formPanel.add(new JLabel("Engine Type:"));
        formPanel.add(engineTypeComboBox);
        formPanel.add(new JLabel("Minimum Version:"));
        formPanel.add(minimumVersionComboBox);
        formPanel.add(new JLabel("Engine Version:"));
        formPanel.add(engineVersionComboBox);

        add(formPanel, BorderLayout.CENTER);

        if (rowData.isEmpty()) {
            carTypeComboBox.setSelectedIndex(-1);
            engineTypeComboBox.setSelectedIndex(-1);
            minimumVersionComboBox.setSelectedIndex(-1);
            engineVersionComboBox.setSelectedIndex(-1);
            makeField.setText("");
            modelField.setText("");
            yearField.setText("");
            powerField.setText("");
        } else {
            carTypeComboBox.setSelectedItem(rowData.get(0));
            makeField.setText((String) rowData.get(1));
            modelField.setText((String) rowData.get(2));
            yearField.setText((String) rowData.get(3));
            minimumVersionComboBox.setSelectedItem(rowData.get(4));
            engineTypeComboBox.setSelectedItem(rowData.get(5));
            powerField.setText((String) rowData.get(6));
            engineVersionComboBox.setSelectedItem(rowData.get(7));
        }

        JPanel buttonsPanel = new JPanel();
        JButton addButton = new JButton("Add Row");
        addButton.addActionListener(e -> {
            String carType = (String) carTypeComboBox.getSelectedItem();
            String make = makeField.getText();
            String model = modelField.getText();
            String year = yearField.getText();
            String minimumVersion = (String) minimumVersionComboBox.getSelectedItem();
            String engineType = (String) engineTypeComboBox.getSelectedItem();
            String power = powerField.getText();
            String engineVersion = (String) engineVersionComboBox.getSelectedItem();

            Vector<Object> newRow = new Vector<>();
            newRow.add(carType);
            newRow.add(make);
            newRow.add(model);
            newRow.add(year);
            newRow.add(minimumVersion);
            newRow.add(engineType);
            newRow.add(power);
            newRow.add(engineVersion);

            DefaultTableModel modelTable = (DefaultTableModel) table.getModel();
            modelTable.addRow(newRow);

            dispose();
        });
        buttonsPanel.add(addButton);
        add(buttonsPanel, BorderLayout.SOUTH);

        setSize(400, 400);
        setLocationRelativeTo(parent);
    }
}
