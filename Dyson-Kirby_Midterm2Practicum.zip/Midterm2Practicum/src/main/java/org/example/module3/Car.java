package org.example.module3;

public class Car {
    public Long id;
    public String carType;
    public String make;
    public String model;
    public String year;
    public String minimumVersion;
    public String engineType;
    public int power;
    public String engineVersion;
}
