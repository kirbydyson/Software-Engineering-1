import org.example.module1.*;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

class RegularCarTest {
    private RegularCar car1;
    private RegularCar car2;
    private RegularCar car3;

    @BeforeEach
    void setUp() throws Exception {
        car1 = new RegularCar("Honda", "Civic", "2020", "v2.0", new RegularCarEngine(20, "v3.0"));
        car2 = new RegularCar("Toyota", "Camry", "2020", "v3.0", new RegularCarEngine(30, "v4.0"));
        car3 = new RegularCar("Ford", "Mustang", "2010", "v3.0", new RegularCarEngine(20, "v3.0"));
    }

    @AfterEach
    void tearDown() {
        car1 = null;
        car2 = null;
        car3 = null;
    }

    @Test
    void moveTest() {
        car1.move();
        assertEquals("Power: 20 , Engine Type: Regular Car Engine", car1.getEngine().power());
        car2.move();
        assertEquals("Power: 30 , Engine Type: Regular Car Engine", car2.getEngine().power());
        car3.move();
        assertEquals("Power: 20 , Engine Type: Regular Car Engine", car3.getEngine().power());
    }

    @Test
    void wrongEngineTypeTest() {
        assertThrows(Car.WrongEngineType.class, () -> {
            car1 = new RegularCar("Honda", "Civic", "2020", "v2.0", new LuxuryCarEngine(20, "v3.0"));
        });
    }

    @Test
    void rightEngineTypeTest(){
        if(car1.getEngine() instanceof RegularCarEngine) {
            System.out.println("Pass: Regular Car Engine");
        }
    }

    @Test
    void wrongVersionTest() {
        assertThrows(Car.WrongVersionException.class, () -> {
            car1 = new RegularCar("Honda", "Civic", "2020", "v2.0", new RegularCarEngine(20, "v1.0"));
        });
    }

    @Test
    void takeEngineTest() throws Exception {
        car1.takeEngine(car3);
        assertEquals("v3.0", car3.getEngine().getVersion());
    }
}
