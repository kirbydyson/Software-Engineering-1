package module2;

public class Printer {
    private int count = 1;

    public synchronized void print(Thread thread) {
        int id = Integer.parseInt(thread.getName());
        while (id != count) {
            try {
                wait();
            } catch (InterruptedException ignored) {
            }
        }
        System.out.println("Thread " + id);
        count++;
        notifyAll();
    }

    public static void main(String[] args) {
        Printer printer = new Printer();

        for (int i = 1; i <= 20; i++) {
            Thread thread = new Thread(() -> {
                printer.print(Thread.currentThread());
            });
            thread.setName(Integer.toString(i));
            thread.start();
        }
    }
}
