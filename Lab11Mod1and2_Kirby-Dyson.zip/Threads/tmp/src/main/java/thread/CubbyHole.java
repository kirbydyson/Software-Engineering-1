package thread;

import java.util.*;

class CubbyHole {
	private int seq;
	private boolean available = false;
	private Queue<Integer> prods = new LinkedList<>();

	public synchronized int get() {
		while (available == false) {
			try {
				wait();
			} catch (InterruptedException e) {
			}
		}
		available = false;
		notify();
		seq = prods.poll();
		return seq;
	}

	public synchronized void put(int value) {
		while (available == true && prods.size() == 10) {
			try {
				wait();
			} catch (InterruptedException e) {
			}
		}
		prods.add(value);
		available = true;
		notify();
	}
}